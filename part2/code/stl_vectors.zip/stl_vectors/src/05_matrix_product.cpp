#include<iostream>
#include <gtest/gtest.h>
#include <vector>

using namespace std;

//alias for matrix and vector
using Matrix= vector<vector<float>>;
using Vector = vector<float>;


//Initializing the main matrix
Matrix A{{1,2,3,4},{5,6,7,8},{9,10,11,12}};


//Initializing the vector
Vector X(4,1);

//function matrix product
Vector matrix_product(Matrix & A, Vector X)
{
    //Compute the matriciel product between A and X

    //your code here
}

TEST(product, size)
{

   auto out = matrix_product(A ,  X);

   EXPECT_EQ(out.size(), 3);
}

TEST(product, values)
{

   auto out = matrix_product(A ,  X);
   Vector exp{10,26,42};

   for(int i=0; i<3; i++)
   {
       EXPECT_FLOAT_EQ(out[i], exp[i]);
   }

   
}

using namespace std;


int main(int argc, char **argv) {
      ::testing::InitGoogleTest(&argc, argv);
      return RUN_ALL_TESTS();
}    
