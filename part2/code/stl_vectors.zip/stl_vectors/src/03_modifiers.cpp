#include <iostream>
#include <vector>

using namespace std;
template<class T> ostream& operator<<(ostream & out, const vector<T> & V)
{
    for(auto v: V)
        out<<v<<" ";
    out<<endl;
    return out;
}

int main(int argc, char *argv[])
{
  vector<float> V;

  cout<<"Pushing 1 to 5: "<<endl;
  //Pushing back 5 elements
  for(int i=0; i<5; i++)
      V.push_back(i+1);
  cout<<V;
   

  //Getting then removing the last three  elements
  cout<<"Removing the last three elements:"<<endl;
  for(int i=0; i<3; i++)
  {
      cout<<V.back()<<" ";
      V.pop_back();
  }
  cout<<endl;


  //Insérer au début
  V.insert(V.begin(), -12);

  cout<<"Inserting -12 at begining: "<<endl;
  cout<<V;


  //Insérer à une position 3
  V.insert(V.begin()+3, -20);
  cout<<"Inserting -20 at index 3:"<<endl;
  cout<<V;

  //Destruction du premier élément
  cout<<"Erasing the first element: "<<endl;
  V.erase(V.begin());
  cout<<V;


  //Destructing from begin to end
  cout<<"Erasing from begin to end"<<endl;
  V.erase(V.begin(), V.end());
  cout<<V;
  return 0;
}
