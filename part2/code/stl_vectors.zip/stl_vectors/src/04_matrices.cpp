#include <iostream>
#include <string>
#include <vector>
using namespace std;

int main(int argc, char *argv[])
{
    //Déclarer une matrice de taille 3x3
    float A[3][3]={{1,2,3},{4,5,6},{7,8,9}};


    //Parcourir la matrice (double indice)
    for(int i=0; i<3; i++)
    {
        for(int j=0; j<3; j++)
            cout<<A[i][j]<<" ";
        cout<<endl;
    }


    //Utiliser la classe vector
    vector<vector<int>> matrix(4, vector<int>(4));


    //Loop using indices
    for(int i=0; i<4; i++)
        for(int j=0; j<4; j++)
            matrix[i][j] = -14;


    //Loop using for each
    for(auto line : matrix)
    {
        for(auto val: line)
            cout<<val<<" ";
        cout<<endl;
    }



    return 0;
}
