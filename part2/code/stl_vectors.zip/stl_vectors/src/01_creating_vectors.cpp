#include <iostream>
#include <vector>

using namespace std;

int main(int argc, char *argv[])
{
  
  //Creating an empty vector O(1)
  vector<int> E1;

  //printing the size and capcity
  cout<<"Size: "<<E1.size()<<"\t Capacity: "<<E1.capacity()<<endl;


  //Creating a vector with given size
  vector<int> E2(10);
  cout<<"Size: "<<E2.size()<<"\t Capacity: "<<E2.capacity()<<endl;


  //Initializing with given size and initial value
  vector<int> E3(10, -14);
  for(auto v: E3)
      cout<<v<<" ";
  cout<<endl;


  //inializing with pointers
  int arr[5]{14, 13, 2, 19, 8};

  vector<int> E4(arr, arr+4);
  for(auto v: E4)
      cout<<v<<" ";
  cout<<endl;


  //initializing with another vector
  vector<int> E5(E4.begin(), E4.begin()+3);
  for(auto v: E5)
      cout<<v<<" ";
  cout<<endl;

  return 0;
}
