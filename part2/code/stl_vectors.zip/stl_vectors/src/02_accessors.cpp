#include <iostream>
#include <vector>


using namespace std;

int main(int argc, char *argv[])
{
  vector<int> V;


  //checking if the vector is empty
  cout<<"Check emptyness: "<<V.empty()<<endl;
  //Size and capacity  
  for(int i=0; i<16; i++)
  {
      //adding a value seen later
      V.push_back(0);

      cout<<"[L: "<<V.size()<<", C: "<<V.capacity()<<"]\n";
  }


  //Front and Back
  V.front() = -12;
  V.back() = -12;
  for(auto v: V)
      cout<<v<<" ";
  cout<<endl;


  return 0;
}
