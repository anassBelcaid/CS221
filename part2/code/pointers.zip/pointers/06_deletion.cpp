#include <iostream>

using namespace std;



int main(int argc, char *argv[])
{
  //pointeur simple   
  int *ptr;

  ptr = new int;
  *ptr = 45;

  cout<<*ptr<<endl;
  
  //Détruire la valeur ptr
  delete ptr;


  //Réserver un tableau
  ptr = new int[5];
  for(int i=0; i<5; i++)
      ptr[i] = i+1;

  for(int *p = ptr; p< ptr+5; p++)
      cout<<*p<<" ";
  cout<<endl;

  //Détruire l'espace
  delete [] ptr;

  //Aussi n'as pas de sens car on vient de détruire
  for(int *p = ptr; p< ptr+5; p++)
      cout<<*p<<" ";
  cout<<endl;

  return 0;
}
