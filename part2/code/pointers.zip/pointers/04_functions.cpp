#include <iostream>

using namespace std;


//First function no hope
void swap_copy(int a, int b)
{
    auto tmp = a;
    a        = b;
    b        = tmp;

}

//Second version (Prefered) references
void swap_ref(int &a, int &b)
{
    auto tmp = a;
    a        = b;
    b        = tmp;

}


//Third version (advanced) adresse
void swap_add(int *a, int *b)
{
    auto tmp = *a;
    *a       = *b;
    *b       = tmp;

}


int main()
{
  int a = 45;
  int b = 30;
 
  //Calling the first one
  swap_copy(a, b);
  cout<<"State after swap copy: \n";
  cout<<"[a: "<<a<<", b:"<<b<<"]\n";

  //Calling the second one
  swap_ref(a, b);
  cout<<"State after swap_ref: \n";
  cout<<"[a: "<<a<<", b:"<<b<<"]\n";


  a = 45;
  b = 30;

  //Call by adress (pay attention to the adresses)
  swap_add(&a, &b);
  cout<<"State after swap_add: \n";
  cout<<"[a: "<<a<<", b:"<<b<<"]\n";


  return 0;
}
