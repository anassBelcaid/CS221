#include <iostream>
#include <string>
#include <vector>

using namespace std;


int main(int argc, char *argv[])
{
   //Déclarer deux variables simples
  int a = 13;
  int b = 15;

  //Déclarer une 
  cout<<"adresse de a: "<<&a<<endl;
  cout<<"adresse  de b: "<<&b<<endl;

  //Constuire un variable qui peut contenir une adresse
  int* p;
  
  //p  va recevoir la mémoire de a
  p = &a;

  cout<<"P pointe sur : "<<p<<endl;

  //Maintenant p va changer de place
  p = &b;

  cout<<"Maintenant P pointe sur : "<<p<<endl;
  return 0;
}
