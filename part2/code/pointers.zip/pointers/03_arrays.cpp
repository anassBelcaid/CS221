#include <iostream>
#include <string>
#include <vector>

using namespace std;


int main(int argc, char *argv[])
{
  int a[]{1,2,3,4,5,6,7,8};

  //loop with indices
  for(int i=0; i<8; i++)
      cout<<a[i]<<" ";
  cout<<endl;

  //Loop with extraction and adresse
  for(int i=0; i<8; i++)
      cout<<*(a+i)<<" ";
  cout<<endl;


  //Loop using raw pointer
  for(int *p = a; p<a+8; p++)
      cout<<*p<<" ";
  cout<<endl;
  return 0;
}
