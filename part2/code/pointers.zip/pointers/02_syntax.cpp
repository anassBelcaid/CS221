#include <iostream>
#include <string>
#include <vector>

using namespace std;


int main(int argc, char *argv[])
{

   //Decraling a simple pointer
   int a = 14;
   int* p = &a;

   //Afficher [(adress|value)] par deux mécanismes
   cout<<"[value: "<<a<<", adress: "<<&a<<"]"<<endl;
   cout<<"[value: "<<*p<<", adress: "<<p<<"]"<<endl;


   //Arithmétique
   int tab[]{1,2,3,4,5,6,7,8,9};

   //Parcourir le tableau par un pointeur
   for(int* p=tab; p < tab + 9; p++)
       cout<<*p<<" ";

  return 0;
}
