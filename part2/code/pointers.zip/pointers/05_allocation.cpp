#include <iostream>

using namespace std;


int main(int argc, char *argv[])
{
  int *a;  

  //Allocation dynamique
  a = new int;
  *a = 45;
  cout<<"Valeur de a: "<<*a<<endl;


  // Allocation d'un tableau
  a = new int[10];

  //Remplir a
  for(int i=0; i<10; i++)
      a[i] = i+1;

  //Afficher le tableau
  for(int i=0; i<10; i++)
      cout<<a[i]<<" ";
  cout<<endl;


  //Changer la taille de a car il faut supprimer l'espace précédant
  a = new int[20];

  //Remplir a
  for(int i=0; i<20; i++)
      a[i] = i+1;

  //Afficher le tableau
  for(int i=0; i<20; i++)
      cout<<a[i]<<" ";
  cout<<endl;

  return 0;
}
