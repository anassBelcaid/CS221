#include<iostream>
#include<string>

#include "gtest/gtest.h"

using namespace std;


int findnumbers(int tab[], int n)
{
    //Your code here
    

}


TEST(findnumbers, example1)
{ 
        int arr[]{12,345,2,6,7896};

        EXPECT_EQ(findnumbers(arr, 5), 2);
}

TEST(findnumbers, example2)
{
    int arr[]{555,901,482,1771};

    EXPECT_EQ(findnumbers(arr, 4), 1);
}

TEST(findnumbers, example3)
{
    int arr[]{12, 1222, 34, 345};

    EXPECT_EQ(findnumbers(arr, 4), 3);
}

int main(int argc, char **argv) {
  ::testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
