#include <iostream>
#include "gtest/gtest.h"


using namespace std;

int linear_search(int arr[], int lenght, int target)
{
    //Your code here
}


TEST(search, debut)
{
    int arr[]{1,4,2,5};

    auto index = linear_search(arr  , 4, 2);
    EXPECT_EQ(index, 2);

}

TEST(search, end)
{
    int arr[]{1,4,2,5};

    auto index = linear_search(arr  , 4, 5);
    EXPECT_EQ(index, 3);

}


TEST(search, doublehit)
{
    int arr[]{1,4,2,5, 4};

    auto index = linear_search(arr  , 5, 4);
    EXPECT_EQ(index, 1);

}

TEST(search, nohit)
{
    int arr[]{1,4,2,5, 4};

    auto index = linear_search(arr  , 5, 7);
    EXPECT_EQ(index, -1);

}

int main(int argc, char *argv[])
{
    
      ::testing::InitGoogleTest(&argc, argv);
      return RUN_ALL_TESTS();
}
