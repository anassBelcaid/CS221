#include<iostream>
#include <gtest/gtest.h>


using namespace std;


bool insert_end(int arr[], int &lenght, int capacity, int value)
{
    //Your code here
}


bool insert_begin(int arr[], int & lenght, int capacity, int value)
{

    //Your code here
}


bool insert_at(int arr[], int & lenght, int capacity, int value, int index)
{

    //Your code here
}


TEST(insertionE, simple)
{
    int arr[3]{1, 2};
    int exp[]{1,2,3};

    //Insérer la valeur 3
    int lenght=2;
    auto val = insert_end(arr, lenght, 3, 3);

    EXPECT_EQ(val, true);
    EXPECT_EQ(lenght, 3);

    for(int i=0; i< 3; i++)
        EXPECT_EQ(arr[i], exp[i]);
    
}


TEST(insertionE, empty)
{
    int arr[3];
    int exp[]{1};

    //Insérer la valeur 3
    int lenght=0;
    auto val = insert_end(arr, lenght, 3, 1);

    EXPECT_EQ(val, true);
    EXPECT_EQ(lenght, 1);

    for(int i=0; i< lenght; i++)
        EXPECT_EQ(arr[i], exp[i]);
    
}

TEST(insertionE, full)
{
    int arr[3]{1, 2, 3};
    int exp[3]{1,2,3};

    //Insérer la valeur 3
    int lenght=3;
    auto val = insert_end(arr, lenght, 3, 3);

    EXPECT_EQ(val, false);
    EXPECT_EQ(lenght, 3);

    for(int i=0; i< lenght; i++)
        EXPECT_EQ(arr[i], exp[i]);
    
}


TEST(insertionB, empty)
{

    int arr[3];
    int exp[3]{1};

    //Insérer la valeur 3
    int lenght=0;
    auto val = insert_begin(arr, lenght, 3, 1);

    EXPECT_EQ(val, true);
    EXPECT_EQ(lenght, 1);

    for(int i=0; i< lenght; i++)
        EXPECT_EQ(arr[i], exp[i]);
}

TEST(insertionB, simple)
{

    int arr[3]{2,3};
    int exp[3]{1,2,3};

    //Insérer la valeur 3
    int lenght=2;
    auto val = insert_begin(arr, lenght, 3, 1);

    EXPECT_EQ(val, true);
    EXPECT_EQ(lenght, 3);

    for(int i=0; i< lenght; i++)
        EXPECT_EQ(arr[i], exp[i]);
}

TEST(insertionB, full)
{

    int arr[3]{1,2,3};
    int exp[3]{1,2,3};

    //Insérer la valeur 3
    int lenght=3;
    auto val = insert_begin(arr, lenght, 3, 1);

    EXPECT_EQ(val, false);
    EXPECT_EQ(lenght, 3);

    for(int i=0; i< lenght; i++)
        EXPECT_EQ(arr[i], exp[i]);
}



TEST(insertionI, empty)
{

    int arr[3];
    int exp[3]{1};

    //Insérer la valeur 3
    int lenght=0;
    auto val = insert_at(arr, lenght, 3, 1, 0);

    EXPECT_EQ(val, true);
    EXPECT_EQ(lenght, 1);

    for(int i=0; i< lenght; i++)
        EXPECT_EQ(arr[i], exp[i]);
}

TEST(insertionI, simple)
{

    int arr[3]{1,3};
    int exp[3]{1,2,3};

    //Insérer la valeur 3
    int lenght=2;
    auto val = insert_at(arr, lenght, 3, 2, 1);

    EXPECT_EQ(val, true);
    EXPECT_EQ(lenght, 3);

    for(int i=0; i< lenght; i++)
        EXPECT_EQ(arr[i], exp[i]);
}



int main(int argc, char *argv[])
{
  ::testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();

}

