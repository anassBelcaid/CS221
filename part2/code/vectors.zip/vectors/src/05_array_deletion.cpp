#include <iostream>
#include "gtest/gtest.h"


using namespace std;


//Function to delete at a given place
bool delete_at(int arr[], int &lenght, int capacity, int index)
{
    //your code here

}

TEST(deletion, empty)
{
    int arr[5];

    //lenght of the array
    int lenght=0;
    
    auto state = delete_at(arr, lenght, 5, 0);
    EXPECT_EQ(state, false);
}

TEST(deletion, simple)
{

    int arr[4]{1,3,2,3};
    int exp[3]{1,2,3}; //Expected array

    //lenght of the array
    int lenght=4;
    
    auto state = delete_at(arr, lenght, 4, 1);
    
    //Constraint on output
    EXPECT_EQ(state, true);


    //Contraint on values
    for(int i=0; i<lenght; i++)
        EXPECT_EQ(arr[i], exp[i]);
}

TEST(deletion, end)
{

    int arr[4]{1,2,3,4};
    int exp[3]{1,2,3}; //Expected array

    //lenght of the array
    int lenght=4;
    
    auto state = delete_at(arr, lenght, 4, 3);
    
    //Constraint on output
    EXPECT_EQ(state, true);


    //Contraint on values
    for(int i=0; i<lenght; i++)
        EXPECT_EQ(arr[i], exp[i]);
}

int main(int argc, char *argv[])
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
