#include <iostream>
#include <random>

using namespace std;
#define N 10


void printArray(int *T, int size)
{
    /*
     * Function to print the content of the array T
     */

    //Printing the array
    for(int i=0;  i <= size; i++)
        cout<<T[i]<<" ";
    cout<<endl;

}

void fillRandom(int *T, int size)
{
    /* funtion to randomly fill the Array T
     * by integers
     * Hint: This function has a bug
     */

    //Random filling the values
    uniform_int_distribution<int> u(0,20);
    default_random_engine e;

    for(int i=0; i <= size; i++)
        T[i] = u(e);

}
void bubbleSort(int * T, int size)
{
    /* Function to buble sort an array T given by
     * its address
     * Hint : this function contains two bugs
     */

    for(int i = 0; i < size; i++)
        for(int j = 0; j < size; j++ )
        {
            //Bubble condition
            if (T[j] > T[j+1])
            {
                // I shoudl a explanation here, but I left that for debugging
                T[j+1] = T[j];
                T[j]   = T[j];
            }
        }
}


int main()
{
   // Static vector with 10 elements
   int *A = new int[N];

   // Fill the array
   fillRandom(A, N);

   //Print the array before sorting
   printArray(A, N);

   //Sort the array
   bubbleSort(A, N);

   //Print the array
   printArray(A, N);


   return 0;

}
