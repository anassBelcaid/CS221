#include <iostream>
#include <vector>
#include <string>
#include "collections/vector.h"
#include "collections/grid.h"
#include "io/console.h"
#include "util/random.h"
#include "graphics/gobjects.h"
#include "graphics/gwindow.h"


using namespace std;

int main() {


    GWindow app(600,600);


    for(auto width = 40; width<=200; width+=10)
    {
        GObject *obj = new GRect(100,300, width, width);
        obj->rotate(45);
        obj->setColor(randomColor());
        app.add(obj);
    }
    return 0;
}
