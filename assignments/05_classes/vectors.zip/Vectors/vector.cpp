#include "vector.h"

//Implements your methods here
