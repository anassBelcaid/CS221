#ifndef VECTOR_H
#define VECTOR_H

template<class T>
class Vector
{
public:
    //Declare all the attributs here
};

#endif // VECTOR_H
