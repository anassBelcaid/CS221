/*
 * File: main.cpp
 * --------------
 * Sample QT project
 */

#include <iostream>
#include "console.h"
#include "testing/SimpleTest.h"
using namespace std;

int main() {
    //Tester votre implementation.
    return 0;
}

