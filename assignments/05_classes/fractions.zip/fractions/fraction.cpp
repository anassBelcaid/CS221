#include "fraction.h"
#include <iostream>

using namespace std;

//Put your implementation here
