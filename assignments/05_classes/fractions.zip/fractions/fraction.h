#ifndef FRACTION_H
#define FRACTION_H
#include <iostream>


class Fraction
{
    //Define your methods and attributs
};

#endif // FRACTION_H
