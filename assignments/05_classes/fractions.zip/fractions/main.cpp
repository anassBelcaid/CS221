/*
 * File: main.cpp
 * --------------
 * Sample QT project
 */

#include <iostream>
#include <sstream>
#include "console.h"
#include "testing/SimpleTest.h"
#include "fraction.h"
using namespace std;

/*
 * This sample main brings up testing menu.
 */
int main() {
    if (runSimpleTests(ALL_TESTS)) {
        return 0;
    }

    cout << "All done, exiting" << endl;
    return 0;
}



PROVIDED_TEST("Checking the empty Constructor")
{
    Fraction Q;

    EXPECT_EQUAL( Q.getNum(), 0);
    EXPECT_EQUAL( Q.getDenom(), 1);
}

PROVIDED_TEST("Checking Real Constructor")
{
    Fraction Q(3, 4);
    EXPECT_EQUAL(Q.getNum(), 3);
    EXPECT_EQUAL(Q.getDenom(), 4);


    Fraction Q2(3.2, 4);
    EXPECT_EQUAL(Q2.getNum(), 3);
    EXPECT_EQUAL(Q2.getDenom(), 4);
}

PROVIDED_TEST("Decimal representation")
{
    Fraction Q(1, 3);

    double val = 1./3;
    EXPECT_EQUAL( Q.decimal(), val);

    Fraction Q2(6, 12);
    EXPECT_EQUAL(Q2.decimal(), 0.5);
}

PROVIDED_TEST("Correct representation")
{
    // First test
    Fraction F(9, 12);
    EXPECT_EQUAL( F.getNum(), 3);
    EXPECT_EQUAL(F.getDenom(), 4);


    //Second test
    Fraction F2(9, 3);
    EXPECT_EQUAL( F2.getNum(), 3);
    EXPECT_EQUAL(F2.getDenom(), 1);


    //Third Test
    Fraction F3(12, 18);
    EXPECT_EQUAL( F3.getNum(), 2);
    EXPECT_EQUAL(F3.getDenom(), 3);


}
PROVIDED_TEST( "Addition")
{
    Fraction F1(3, 12);
    Fraction F2(3, 12);
    auto F3 = F1 + F2;
    EXPECT_EQUAL(F3.getNum(), 1);
    EXPECT_EQUAL(F3.getDenom(), 2);

    Fraction F4(3, 4);
    Fraction F5(1, 2);
    auto F6 = F3 + F4;
    EXPECT_EQUAL(F6.getNum(), 5);
    EXPECT_EQUAL(F6.getDenom(), 4);


}

PROVIDED_TEST("Multiplicaiton")
{
    Fraction F1(3, 12);
    Fraction F2(3, 4);

    auto F3 = F1 * F2;
    EXPECT_EQUAL(F3.getNum(), 3);
    EXPECT_EQUAL(F3.getDenom(), 16);

}

PROVIDED_TEST("Ostream")
{
    Fraction F1(3, 12);
    stringstream ss;
    ss<<F1;
    EXPECT_EQUAL("1/4", ss.str());

}
