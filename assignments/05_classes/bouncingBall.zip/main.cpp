/*
 * File: main.cpp
 * --------------
 * Sample QT project
 */

#include <iostream>
//#include "console.h"
#include "gwindow.h"
#include <unistd.h>
#include <vector>

using namespace std;

/*
 * This sample main brings up testing menu.
 */
int main() {

    //Créer une fenêtre  graphique qui contient des balles qui de déplacent

    return 0;
}

