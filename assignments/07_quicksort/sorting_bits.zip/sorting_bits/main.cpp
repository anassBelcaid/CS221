/*
 * File: main.cpp
 * --------------
 * Sample QT project
 */

#include <iostream>
#include <vector>
#include "console.h"
#include "testing/SimpleTest.h"
using namespace std;

using VecI = vector<int> ;


/*
 * Sort by bits
 */



VecI sortByBits(VecI & I)
{


    return I;
}
/*
 * This sample main brings up testing menu.
 */
int main() {
    if (runSimpleTests(SELECTED_TESTS)) {
        return 0;
    }
    cout << "All done, exiting" << endl;
    return 0;
}


void check_vector_equality(VecI & A, VecI & B)
{
    for(int i=0; i < A.size(); i++)
            EXPECT_EQUAL(A[i], B[i]);
}
PROVIDED_TEST("Example 1 ")
{
  //initial vector
  VecI I{0,1,2,3,4,5,6,7,8};

  //computed value
  auto E = sortByBits(I);

  //expected output
  VecI O{0,1,2,4,8,3,5,6,7};

check_vector_equality(E, O);


}


PROVIDED_TEST("Example 2 ")
{
  //initial vector
  VecI I{1024,512,256,128,64,32,16,8,4,2,1};

  //computed value
  auto E = sortByBits(I);

  //expected output
  VecI O{1,2,4,8,16,32,64,128,256,512,1024};

check_vector_equality(E, O);

}

PROVIDED_TEST("Example 3 ")
{
  //initial vector
  VecI I{2,3,5,7,11,13,17,19};

  //computed value
  auto E = sortByBits(I);

  //expected output
  VecI O{2,3,5,17,7,11,13,19};

check_vector_equality(E, O);

}
