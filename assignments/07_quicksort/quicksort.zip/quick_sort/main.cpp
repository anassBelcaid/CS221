/*
 * File: main.cpp
 * --------------
 * Sample QT project
 */

#include <iostream>
#include <vector>
#include <algorithm>
#include "console.h"
#include "testing/SimpleTest.h"
#include "helper.h"

using namespace std;



/*
 * Partition function
*/

int partition(int * begin, int *end)
{
    //fonction de repartion ou [begin] est un pointeur sur le
    // debut du tableau et [end] est un pointeur sur le dernier element

}


/*
 * Fonction tri rapide
 */

void quickSort(int *begin, int *end)
{
    // Fonction recursive pour trier le tableau en utilisant le tri rapide

}
/*
 * This sample main brings up testing menu.
 */
int main() {
    if (runSimpleTests(SELECTED_TESTS)) {
        return 0;
    }
    cout << "All done, exiting" << endl;
    return 0;
}

PROVIDED_TEST("Partition test1")
{
    //taking a simple vector
    vecI A{2, 8,7,1,3,5,6,4};
    int n = A.size();
    auto P = A.data();

    auto val = partition(P, P+n-1);

    // test on pivot position
    EXPECT_EQUAL(val,  3);

    //Expected results
    vecI R{2,1,3,4,7,5,6,8};

    for(int i=0; i< 8; i++)
       EXPECT_EQUAL(A[i], R[i]);
}

PROVIDED_TEST("Partition test2")
{
    //taking a simple vector
    vecI A{1,4, 5, 9, 2, 1, 3, 9, 10,6};
    int n= A.size();
    auto P = A.data();

    auto val = partition(P, P+n-1);

    // test on pivot position
    EXPECT_EQUAL(val,6);

    //Expected results
    vecI R{1, 4, 5, 2, 1, 3, 6, 9, 10, 9};

    for(int i=0; i< n; i++)
       EXPECT_EQUAL(A[i], R[i]);
}

PROVIDED_TEST("Partition all Left")
{
    //taking a simple vector
    vecI A{1, 5, 9, 10};
    int n= A.size();
    auto P = A.data();

    auto val = partition(P, P+n-1);


    //test on positioni
    EXPECT_EQUAL(val, 3);


    //Expected results
    vecI R{1,5,9,10};

    for(int i=0; i< n; i++)
       EXPECT_EQUAL(A[i], R[i]);
}



PROVIDED_TEST("Partition all Right")
{
    //taking a simple vector
    vecI A{5,2,4,1};
    int n= A.size();
    auto P = A.data();

    auto val = partition(P, P+n-1);
    EXPECT_EQUAL(val, 0);


    //Expected results
vecI R{1,2,4,5};

    for(int i=0; i< n; i++)
       EXPECT_EQUAL(A[i], R[i]);

}

PROVIDED_TEST("Quick Sort 4 elements")
{
    //taking a simple vector
    vecI A{5,2,4,1};

    quickSort(A.data(), A.data() + 3);

    auto test = is_sorted(A.begin(), A.end());
    EXPECT_EQUAL(test, true);


}

PROVIDED_TEST("Quick Sort 40 elements")
{
    //taking a simple vector
    auto Vec = randomVector(40);

    quickSort(Vec.data(), Vec.data() + Vec.size() -1);

    auto test = is_sorted(Vec.begin(), Vec.end());
    EXPECT_EQUAL(test, true);
}


PROVIDED_TEST("Quick Sort 1000 elements")
{
    //taking a simple vector
    auto Vec = randomVector(1000);

    quickSort(Vec.data(), Vec.data() + Vec.size()-1);

    auto test = is_sorted(Vec.begin(), Vec.end());
    EXPECT_EQUAL(test, true);
}
