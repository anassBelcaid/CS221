#include <iostream>
#include <string>
#include <vector>
#include <stdlib.h>
#include <random>

// alias for vector of ints
using vecI = std::vector<int>;


/* simple int value */
std::random_device r;
std::default_random_engine gen(r());



/* Random vector using STl */

vecI randomVector(int n, int low=0, int high = 100)
{
    /* Generate a random vector<int> of size N with values
     * between low and high 
     */

    //generator
    std::uniform_int_distribution<int> uniform(low, high);


    vecI out(n);
    
    //filling with random values
    for(auto &v : out)
        v = uniform(gen);

    return out;

}



/* helper to print a vector */
template<class T>
std::ostream &operator<<( std::ostream & out,  std::vector<T> & V)
{
    for(auto v: V)
        out << v << " ";

    return out;

}



