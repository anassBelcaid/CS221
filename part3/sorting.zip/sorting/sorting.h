#include "helper.h"
#include <algorithm>
using std::swap;


/*
 * Function for a single bubble
 */
void bubble( int * begin, int *end)
{
    /* execute a bubble operation from begin to end (non incluse)
     *
     * begin : pointer on the first memory address
     * end   : pointer on the last memory address
     */
    // Put your code here

    
}

/* 
 * Bubble Sort
*/
void bubble_sort(int * begin, int * end)
{
    // function to perform a bubble sort in the array
    // delimited by begin and end
    
    // Put your code here


}


/* 
 * Single Selection
 */

void selection(int * begin, int * end)
{
    /* Perform a single selection step between 
     * the start memroy [begin] and the end [end]
     */

    // Put your code here
}


/* 
 * Selection sort
 */

void selection_sort( int * begin, int *end)
{

    // Put your code here
}



/*
 * Insertion
 */

void insertion( int * begin, int *end , int value)
{
  // insert the value [value] in the array
  // stored between [begin] and [end]

    // Put your code here
}

/* 
 * Insertion Sort
 */

void insertion_sort(int *begin, int *end)
{
    // put your code here
}


/* 
 * merging
 */
vecI merge(vecI & L, vecI & R)
{
    // function to merge two sorted arrays [L] and [R]
    
    // put your code here

}


/*
 * merge sort
 */

vecI merge_sort( vecI V)
{
    // put your code here


}


