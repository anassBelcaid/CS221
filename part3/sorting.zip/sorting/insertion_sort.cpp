#include <iostream>
#include <algorithm>
#include <cassert>
#include "sorting.h"


using namespace std;


int main(int argc, char *argv[])
{

    //generating a random vector
    auto N = 10;
    auto Vec = randomVector(N);
    cout << "Before sorting : " << endl;
    cout << Vec << endl;

    cout << "After four iterations of bubbles :" << endl;


    auto V = Vec.data();
    //bubble for 5 iteration
    for ( int i=0; i < 5; i++)
        insertion(V, V + i, *(V+ i));
    cout << Vec << endl;
    //simple assertion to check invariant
    assert(is_sorted(V, V+5));


    /* //finishing the sort */
    cout << "Finishing the bubble sort: " << endl;
    insertion_sort(V , V + N);
    assert(is_sorted(V, V + N));
    cout << Vec << endl;

  return 0;
}
