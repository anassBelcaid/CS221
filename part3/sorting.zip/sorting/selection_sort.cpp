#include <iostream>
#include <algorithm>
#include <cassert>
#include "sorting.h"


using namespace std;


int main(int argc, char *argv[])
{

    //generating a random vector
    auto N = 10;
    auto Vec = randomVector(N);
    cout << "Before sorting : " << endl;
    cout << Vec << endl;

    cout << "After four iterations of bubbles :" << endl;
    cout << Vec << endl;


    auto V = Vec.data();
    auto E = V + N;
    //bubble for 5 iteration
    for ( int i=0; i < 5; i++)
        selection(V + i, E );
    
    //simple assertion to check invariant
    assert(is_sorted(V, V+5));
    cout << Vec << endl;


    //finishing the sort
    cout << "Finishing the bubble sort: " << endl;
    selection_sort(V , V + N);
    assert(is_sorted(V, V + N));
    cout << Vec << endl;

  return 0;
}
