#include <iostream>
#include <algorithm>
#include <cassert>
#include "sorting.h"


using namespace std;


int main(int argc, char *argv[])
{

    //generating a random vector
    auto N = 21;
    auto Vec = randomVector(N);
    cout << "Before sorting : " << endl;
    cout << Vec << endl;



    //finishing the sort
    cout << "Finishing the bubble sort: " << endl;
    Vec = merge_sort(Vec);
    auto V = Vec.data();
    assert(is_sorted(V, V + N));
    cout << Vec << endl;

  return 0;
}
