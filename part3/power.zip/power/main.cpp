/*
 * File: main.cpp
 * --------------
 * Sample QT project
 */

#include <iostream>
#include <math.h>
#include "console.h"
#include "testing/SimpleTest.h"
using namespace std;


/* Recursive function to compute the power of x to
 */

double power(double x, int n)
{
    //Pur your recursive call Here

}

/*
 * This sample main brings up testing menu.
 */
int main() {
    if (runSimpleTests(SELECTED_TESTS)) {
        return 0;
    }
    cout << "All done, exiting" << endl;
    return 0;
}

PROVIDED_TEST("TEST1  2^3")
{
    EXPECT_EQUAL(8, power(2, 3));
}

PROVIDED_TEST("TEST2  2^0")
{
    EXPECT_EQUAL(1, power(2, 0));
}

PROVIDED_TEST("TEST3  generalPair")
{
    EXPECT_EQUAL(pow(4.2, 4), power(4.2, 4));

}

PROVIDED_TEST("TEST4  generalImpair")
{
    EXPECT_EQUAL(pow(4.2, 5), power(4.2, 5));
}
