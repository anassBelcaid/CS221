#include <iostream>
#include <string>
#include <fstream>
#include <vector>



using namespace std;

void load_image(const string &filename, vector<int> & data, int & rows, int & cols)
{
    //Do somework to load the image
}

void save_image(const string &filename, vector<int> & data, int & rows, int & cols)
{
    //Work to save the image
}

bool isEmpty(vector<int> & data, int rows, int cols)
{
    if( data.size() == 0 ) 
        return true;

    return false;
}


int main()
{
    //Data of the image
    vector<int>  data;
    int rows;
    int cols;

    //loading the image
    load_image("Lena.png", data, rows, cols);

    //checking if the data
    if (! isEmpty(data, rows, cols) ) 
    {
        //do something
    }

    //Saving the new image
    save_image("new_image.png", data, rows, cols);
}



