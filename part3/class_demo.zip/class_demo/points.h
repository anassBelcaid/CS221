
class Point
{
public:
    Point ();
    Point(float x, float y);
    ~Point ();

    void move(float dx, float dy);
    float distance(const Point & other);
    void Print() const;

private:
    /* data */
    float x;
    float y;
};
