#include <iostream>
#include <math.h>
#include "points.h"


using namespace std;


Point::Point():x(0),y(0){

;}


Point::Point(float x, float y)
{
    this-> x = x;
    this-> y = y;
}


void Point::move(float dx, float dy)
{
    x += dx;
    y += dy;
}

Point::~Point()
{
    /* cout<<"Removing ("<<x<<", "<<y<<")\n"; */
}

float Point::distance(const Point &other)
{
    auto diffX = other.x - x;
    auto diffY = other.y - y;

    return sqrt( diffX * diffX + diffY * diffY);
}

void Point::Print()const
{
    cout<<"("<<x<<", "<<y<<")"<<endl;
}



