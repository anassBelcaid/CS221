#include <iostream>
#include <locale>
#include <string>
#include <vector>

using namespace std;


int add(int a, int b)
{
    return a + b;
}

int main(int argc, char *argv[]) {
  auto a = 0;
  auto b = 1;

  cout << add(a, b) << endl;

  return 0;
}
