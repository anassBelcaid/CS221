#include <iostream>
#include <string>
#include <vector>

#include "points.h"

using namespace std;


int main(int argc, char *argv[])
{
  Point A;       //Default constructor
  Point B(2., 3.4);  //Classical constructor


  //Creating a pointer of type Point
  Point* P = nullptr;


  //Pointing on A;
  P = &A;
  cout<<"P point on A in: "<<endl;
  P->Print();


  //Manipulating A with P ( -> )
  cout<<"Moving P by (2, 1)"<<endl;
  P->move(2, 1);


  //Print A state
  cout<<"Now A is on : "<<endl;
  P->Print();


  //changing P adress
  P = &B;
  cout<<"Now P point on B"<<endl;
  B.Print();

  //Moving
  cout<<"Moving B by (-1,1)"<<endl;
  P->move(-1,1);
  P->Print();


  //Part 2 Creating Points by New
  
  cout<<"Creating a new empty point"<<endl;
  P = new Point;  // Calling new on on default argument
  P->Print();
  delete P;


  //Pointer with no default
  cout<<"Creating a Point on position (4, 5)"<<endl;
  P  = new Point(4, 5);  //New with classical
  P->Print();
  delete P;


  //Creating an array of pointers
  Point * arr = new Point[5]; 

  //Printing the content of the arry
  for( P = arr; P - arr < 5; P++)
  {
      P->Print(); 
      cout<<" ";
  }
  cout<<endl;

  delete [] arr;




  return 0;
}
