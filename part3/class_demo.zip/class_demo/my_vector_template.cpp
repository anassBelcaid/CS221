#include <iostream>

using namespace std;

template <class T>
class vector
{
    public:
    vector(){ size_ = 0;};
    vector(int size)
    {
        //Allocating memory
        data_ = new T[size];
        size_ = size;
    }
    vector(int size, T value)
    {
        //Allocating memory
        data_ = new T[size];
        for(int i=0 ; i<size; i++)
            data_[i] = value;

        size_ = size;

    }
    ~vector()
    {
      delete [] data_;
    }
    
    int size()const
    {
        return size_;
    }

    T & operator[] (int i)const
    {
        return data_[i];
    }

private:
    T * data_= nullptr;
    int size_;
};


template<class T>
ostream& operator<<(ostream& out, const vector<T> & V)
{
    out <<"{";
    for(int i=0; i< V.size(); i++)
        out<<V[i]<< " ";
    return out;
}

int main(int argc, char *argv[])
{
   
  vector<int> V(4);
  V[0] = 1;
  V[1] = 2;
  V[2] = 3;
  V[3] = 4;
  cout<< V << endl;


  return 0;
}
