#include <iostream>
#include <string>
#include <vector>

using namespace std;


class Complex
{
public:

    Complex( double r =0, double im= 0):real_(r),imag_(im){};


    //operators
    Complex operator+(Complex & other)
    {
        return Complex(this->real_ + other.real_, 
                this->imag_ + other.imag_);
    }


    friend ostream& operator<<(ostream&, const Complex &);

private:
    /* data */
    double real_;
    double imag_;
};


ostream& operator<<(ostream& out, const Complex & C)
{
    out <<"("<< C.real_ <<"+ "<<C.imag_<<"j)";
    return out;
}

int main(int argc, char *argv[])
{
  Complex C1(2, 1);
  Complex C2(4, 3);
  

  //Ajouter C1 et C2
  auto C3 = C1 + C2;

  cout<< C1 <<" + " << C2 << "= "<< C3 <<endl;
  return 0;
}
