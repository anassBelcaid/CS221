#include <iostream>
#include "points.h"

using namespace std;

int main()
{
    
    //Creating an emtpy point
    Point A;
    A.Print();


    //Creating a point with a given position
    Point B(3., 4);
    B.Print();


    //Using the copy constructor
    Point C(B);
    C.Print();


    //Applying some modifiers
    //
    B.move(2, 1);
    B.Print();


    auto dist= B.distance(A);
    cout<<"Distance between A and B: "<< dist<<endl;


}

