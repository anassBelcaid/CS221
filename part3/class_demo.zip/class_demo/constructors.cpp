#include <iostream>
#include <string>
#include <vector>

using namespace std;

class SomeClass
{
public:
    SomeClass ()
    {cout<<"default"<<endl;};           //Default constuctor

    SomeClass(int a)                 //Custom constructor
    {
        cout<<"with 1 value"<<endl;
    };       

    SomeClass(int a, float b)       //With two values
    {
        cout<<"With two values"<<endl;
    }

    ~SomeClass (){}           //Destructor

};

int main(int argc, char *argv[])
{
  SomeClass var_1;            //Call default

  SomeClass var_2(2);          //Second constructor
  
  SomeClass var_3(1, 4.2);          //third constructror

  //Also recommended unifrom initializer
  SomeClass var_4{};

  SomeClass var_5 = {10, 10.0};


  return 0;
}
