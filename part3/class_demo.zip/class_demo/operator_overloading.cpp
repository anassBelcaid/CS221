#include <iostream>
#include <string>
#include <vector>

using namespace std;

// Class definition
class Counter {
public:
  Counter() : count_(0){};

  // opeartors
public:
  void operator++ ()
  {
      count_ ++;
  }
  
  void operator++ (int) 
  {
      count_ += 2;
  }

  void operator+=(int value)
  {
      count_ += value;
}


private:
  int count_;


//Friends
friend ostream & operator<<(ostream&, const Counter &);
};


ostream & operator<<(ostream & out, const Counter & C)
{
    out<< "Counter("<< C.count_<< ")";


    return out;
}
int main(int argc, char *argv[]) {
  Counter c;

  // Augmenter la valeur de c par 1
  ++c;
  cout<< c<<endl;


  // Augmenter la valeur de c par 4
  c += 5;
  cout<< c << endl;

  return 0;
}
